import { useState } from "react";
import { SectionHeader } from "./SectionHeader";

const references = [
  { name: "La La Land", category: "Filme" },
  { name: "Mr. Nobody", category: "Filme" },
  { name: "Amélie Poulain", category: "Filme" },
  { name: "Brilho Eterno de uma Mente sem Lembranças", category: "Filme" },
  { name: "Marriage Story", category: "Filme" },
  { name: "Pride and Prejudice", category: "Filme" },
];

const technicalDetails = [
  { label: "Fotografia", value: "Edição · Direção · Atuação" },
  { label: "Recursos", value: "Luz de geladeira, velas, iluminação caseira, pós-produção em Photoshop" },
  { label: "Colaboração", value: "João FTK" },
  { label: "Período", value: "2019 – 2020" },
];

export function Exposicao() {
  const [hoveredRef, setHoveredRef] = useState<string | null>(null);

  return (
    <section id="exposicao" className="relative py-28 lg:py-36">
      <div className="max-w-6xl mx-auto px-6">
        <SectionHeader number="05" title="Exposição" subtitle="Projeto autoral de fotografia concebido durante a pandemia." />

        <div className="grid lg:grid-cols-5 gap-12 lg:gap-16">
          {/* Description — 3 cols */}
          <div className="lg:col-span-3 reveal">
            <div className="space-y-6">
              <p className="font-serif text-lg leading-relaxed text-warm-gray/80">
                Cenas icônicas de{" "}
                <span className="text-off-white italic">clipes, filmes e esculturas</span>{" "}
                foram recriadas em casa com iluminação cinematográfica improvisada —{" "}
                <span className="text-gold/80">geladeira, velas e Photoshop</span>{" "}
                — em parceria com João FTK.
              </p>
              <p className="font-serif text-base leading-relaxed text-warm-gray/60">
                O projeto demonstra habilidade técnica e criatividade de produção com
                baixo orçamento, transformando limitações em linguagem artística.
              </p>
            </div>

            {/* References */}
            <div className="mt-12">
              <h3 className="font-mono text-[10px] tracking-[0.25em] uppercase text-warm-gray/40 mb-5">
                Referências recriadas
              </h3>
              <div className="flex flex-wrap gap-2">
                {references.map((ref, i) => (
                  <button
                    key={i}
                    onMouseEnter={() => setHoveredRef(ref.name)}
                    onMouseLeave={() => setHoveredRef(null)}
                    className={`relative px-4 py-2 font-serif text-sm rounded-sm border transition-all duration-400 ${
                      hoveredRef === ref.name
                        ? "border-gold/40 text-gold bg-gold/[0.04]"
                        : "border-white/[0.06] text-warm-gray/70 hover:border-white/[0.12] hover:text-off-white"
                    }`}
                  >
                    {ref.name}
                    <span className={`absolute -top-1 -right-1 font-mono text-[7px] tracking-wider uppercase px-1.5 py-0.5 rounded-full bg-dark-bg border border-white/10 text-warm-gray/40 transition-opacity duration-300 ${
                      hoveredRef === ref.name ? "opacity-100" : "opacity-0"
                    }`}>
                      {ref.category}
                    </span>
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Technical details — 2 cols */}
          <div className="lg:col-span-2 reveal">
            <div className="rounded-sm border border-white/[0.06] bg-white/[0.01] p-6 space-y-0">
              <h3 className="font-mono text-[10px] tracking-[0.25em] uppercase text-warm-gray/40 mb-6">
                Ficha Técnica
              </h3>
              {technicalDetails.map((detail, i) => (
                <div
                  key={i}
                  className={`py-4 ${i < technicalDetails.length - 1 ? "border-b border-white/[0.04]" : ""}`}
                >
                  <div className="font-mono text-[9px] tracking-[0.2em] uppercase text-gold/60 mb-1.5">
                    {detail.label}
                  </div>
                  <div className="font-serif text-sm text-off-white/70 leading-relaxed">
                    {detail.value}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
